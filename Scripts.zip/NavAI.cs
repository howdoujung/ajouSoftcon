using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NavAI : MonoBehaviour
{
    public Transform target;
    Animator animator;
    NavMeshAgent agent;
    float speed = 0;
    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        speed = agent.velocity.magnitude;
        agent.SetDestination(target.position);
        animator.SetFloat("Speed", speed);
    }
}
